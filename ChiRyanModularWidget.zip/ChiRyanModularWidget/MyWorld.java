import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    private static int health = 1212314;
    private static int score = 14;
    private static int var = -99982;
    private RCStatsBar stats1 = new RCStatsBar("Health", health, "Score", score, "Var", var);
    private static boolean animate = false;
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        addObject(stats1, 300, 200);
        stats1.changeLineColour(Color.RED);
        stats1.changeFillColour(Color.RED);
    }

    public void act()
    {
        if (Greenfoot.isKeyDown("left"))
        {
            score--;
            health--;
            var--;
            stats1.update( "Health", health, "Score", score, "Var", var);
        }
        if (Greenfoot.isKeyDown("right"))
        {
            score++;
            health++;
            var++;
            stats1.update( "Health", health, "Score", score, "Var", var);
        }
        
        if (Greenfoot.isKeyDown("up"))
        {
            toggleAnimate();
        }

    }
    
    public void toggleAnimate()
    {
        if (!animate)
        {
            stats1.enableAnimate();
            animate = true;
        }
        else
        {
            stats1.disableAnimate();
            animate = false;
        }
    }
    
}
